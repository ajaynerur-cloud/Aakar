@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Aakar-Icon.ps1"
pause
