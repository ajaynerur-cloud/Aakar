Remove-Item -Recurse -Force 'HKCU:\Software\Classes\.aakar','HKCU:\Software\Classes\Aakar.Model' -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\Aakar" -ErrorAction SilentlyContinue
Write-Host 'Aakar file type removed.'
